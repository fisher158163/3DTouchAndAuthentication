//
//  DetailViewController.h
//  TableViewCell编辑
//
//  Created by Liyu on 16/8/18.
//  Copyright © 2016年 liyu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@property(nonatomic,strong)NSString *textStr;
@property(nonatomic,strong)NSString *headImageStr;
@end
