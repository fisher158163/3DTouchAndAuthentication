//
//  DetailTableViewCell.h
//  TableViewCell编辑
//
//  Created by Liyu on 16/8/18.
//  Copyright © 2016年 liyu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *headImage;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

@end
